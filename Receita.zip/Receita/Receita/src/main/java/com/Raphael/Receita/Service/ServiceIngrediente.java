package com.Raphael.Receita.Service;
import com.Raphael.Receita.Modal.Ingredient;
import com.Raphael.Receita.Repository.RepositoryIngrediente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServiceIngrediente {
    @Autowired
    private RepositoryIngrediente repositoryIngrediente;

    public Ingredient salvar(Ingredient ingredient){
        return repositoryIngrediente.save(ingredient);
    }
    public List<Ingredient> listar(){
        return repositoryIngrediente.findAll();
    }
    public Ingredient buscarPorId(Long id){
        return repositoryIngrediente.findById(id).orElse(null);
    }
    public Ingredient atualizar(Long id, Ingredient ingredient){
        ingredient.setId(id);
        return repositoryIngrediente.save(ingredient);
    }
    public void deletar(Long id) {
        repositoryIngrediente.deleteById(id);
    }

}
