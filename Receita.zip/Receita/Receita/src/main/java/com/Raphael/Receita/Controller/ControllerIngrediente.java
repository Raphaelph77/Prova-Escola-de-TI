package com.Raphael.Receita.Controller;
import com.Raphael.Receita.Modal.Ingredient;
import com.Raphael.Receita.Service.ServiceIngrediente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/ingrediente")
public class ControllerIngrediente {
    @Autowired
    private ServiceIngrediente service;

    @GetMapping
    public List<Ingredient> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Ingredient buscar(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Ingredient salvar(@RequestBody Ingredient ingredient) {
        return service.salvar(ingredient);
    }

    @PutMapping("/{id}")
    public Ingredient atualizar(@PathVariable Long id, @RequestBody Ingredient ingredient) {
        return service.atualizar(id, ingredient);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        service.deletar(id);
    }

}
