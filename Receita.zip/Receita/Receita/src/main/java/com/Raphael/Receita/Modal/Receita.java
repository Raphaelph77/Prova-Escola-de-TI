package com.Raphael.Receita.Modal;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Setter
@Getter
@Entity
@Table(name = "receita")
public class Receita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nome;
    private int tempoPreparo;
    private double custoAproximado;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "receita")
    private List<Ingredient> ingredientes;
}
