package com.Raphael.Receita.Controller;
import com.Raphael.Receita.Modal.Receita;
import com.Raphael.Receita.Service.ServiceReceita;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/receita")
public class ControllerReceita {
    @Autowired
    private ServiceReceita service;

    @GetMapping
    public List<Receita> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Receita buscar(@PathVariable Long id) {
        return service.buscarPorId(id);
    }

    @PostMapping
    public Receita salvar(@RequestBody Receita receita) {
        return service.salvar(receita);
    }
    @PutMapping("/{id}")
    public Receita atualizar(@PathVariable Long id, @RequestBody Receita receita) {
        return service.atualizar(id, receita);
    }
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        service.deletar(id);
    }
}