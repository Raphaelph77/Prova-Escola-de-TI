package com.Raphael.Receita.Service;
import com.Raphael.Receita.Modal.Receita;
import com.Raphael.Receita.Repository.RepositoryReceita;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ServiceReceita {
    @Autowired
    private RepositoryReceita repositoryReceita;

    public Receita salvar(Receita receita){
        return repositoryReceita.save(receita);
    }
    public List<Receita> listar(){
        return repositoryReceita.findAll();
    }
    public Receita buscarPorId(Long id){
        return repositoryReceita.findById(id).orElse(null);
    }
    public Receita atualizar(Long id, Receita receita){
        receita.setId(id);
        return repositoryReceita.save(receita);
    }
    public void deletar(Long id) {
        repositoryReceita.deleteById(id);
    }
}